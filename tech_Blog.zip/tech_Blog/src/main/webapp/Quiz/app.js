
function open(num)
{
	console.log(num)
}		


const quizData = [{
    question: "Which of the following is a client site language?",
    a: "Java",
    b: "C",
    c: "Python",
    d: "JavaScript",
    correct: "d",
},
{
    question: "What does HTML stand for?",
    a: "Hypertext Markup Language",
    b: "Cascading Style Sheet",
    c: "Jason Object Notation",
    d: "Helicopters Terminals Motorboats Lamborginis",
    correct: "a",
},
{
    question: "What year was JavaScript launched?",
    a: "1996",
    b: "1995",
    c: "1994",
    d: "none of the above",
    correct: "b",
},
{
    question: "What does CSS stands for?",
    a: "Hypertext Markup Language",
    b: "Cascading Style Sheet",
    c: "Jason Object Notation",
    d: "Helicopters Terminals Motorboats Lamborginis",
    correct: "b",
},
{

question: "find the next series?"+"<img src=\"quez.jpg\" width=\"540\" height=\"130\">",
a: "A",
b: "B",
c: "C",
d: "D",
e:"E",
f:"F",
correct: "b",
}


];
let index = 0;
let correct = 0,
incorrect = 0,
total = quizData.length;
let questionBox = document.getElementById("questionBox");
let allInputs = document.querySelectorAll("input[type='radio']")
var v=document.getElementById('time1').innerText;
const loadQuestion = () => {
if (total === index)  {
    return quizEnd()
}
reset()
const data = quizData[index]
questionBox.innerHTML = `${index + 1}) ${data.question}`
allInputs[0].nextElementSibling.innerText = data.a
allInputs[1].nextElementSibling.innerText = data.b
allInputs[2].nextElementSibling.innerText = data.c
allInputs[3].nextElementSibling.innerText = data.d

}

document.querySelector("#submit").addEventListener(
"click",
function() {
    const data = quizData[index]
    const ans = getAnswer()
    if (ans === data.correct) {
        correct++;
    } else {
        incorrect++;
    }
    index++;
    loadQuestion()
}
)

const getAnswer = () => {
let ans;
allInputs.forEach(
    (inputEl) => {
        if (inputEl.checked) {
            ans = inputEl.value;
        }
    }
)
return ans;
}

const reset = () => {
allInputs.forEach(
    (inputEl) => {
        inputEl.checked = false;
    }
)
}

function f1(){
    window.location.href="quiz_main.jsp";
}
const quizEnd = () => {
// console.log(document.getElementsByClassName("container"));
document.getElementById('video').style="visibility:hidden";
document.getElementById("header").style="width:100%";
document.getElementsByClassName("container")[0].innerHTML = `
    <div class="col">
        <h3 class="w-100"> Hii, you've scored ${correct} / ${total} </h3>
        &nbsp;&nbsp;<button id="home" onclick="f1()">go to home</button>
    </div>
   
    
    
`
document.getElementById('time1').setAttribute("style","display:none");

}
loadQuestion(index);


function time()
{
     min=9;
     sec=60;
    function start()
    {
        document.getElementById('time1').innerText=min+":"+sec;
        sec--;
        if(sec==0)
        {
            min--;
            sec=60;
        }
        if(min==-1)
        {
            document.getElementById('time1').innerText=0+":"+0;
            stop();
        }
    }
    function stop()
    {
        clearInterval(s);
        quizEnd();
    }
    var s=setInterval(start,1000)
}
navigator.mediaDevices.getUserMedia({video:true}).then((s)=>
{
document.getElementById('video').srcObject=s;
}).catch((error)=>
{
console.log(error)
});



document.addEventListener('keydown',(e)=>
{
    console.log(e.code);
    if(e.code=="Tab"||e.code=="MetaLeft")
    quizEnd();
    console.log(e.code);
})
