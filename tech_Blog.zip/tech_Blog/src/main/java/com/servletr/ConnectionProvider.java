package com.servletr;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class ConnectionProvider
 */
@WebServlet("/ConnectionProvider")
public class ConnectionProvider 
{
	private static Connection con;
	public static Connection getConnection() {
		
		if(con==null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/utkarsh", "root","Utkarsh$2002");
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return con;
	}
}
