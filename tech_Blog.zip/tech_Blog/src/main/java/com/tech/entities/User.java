package com.tech.entities;

import java.sql.*;

public class User {
	private int id;
	private String uname;
	private String email;
	private String pass;
	private String gender;
	private Timestamp dateTime;
	private String about;
	private String profile;
	private String role;

	public User(int id, String uname, String email, String pass, String gender, Timestamp dateTime, String about, String role) {
		this.id = id;
		this.uname = uname;
		this.email = email;
		this.pass = pass;
		this.gender = gender;
		this.dateTime = dateTime;
		this.about = about;
		this.role = role;
	}

	public User() {

	}

	public User(String uname, String email, String pass, String gender, String about, String role) {
		this.uname = uname;
		this.email = email;
		this.pass = pass;
		this.gender = gender;
		this.about = about;
		this.role = role;
	}

//	getter and setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return uname;
	}

	public void setName(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPassword(String pass) {
		this.pass = pass;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Timestamp getDateTime() {
		return dateTime;
	}

	public void setDateTime(Timestamp dateTime) {
		this.dateTime = dateTime;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getProfile() {
		return profile;
	}

	public void setProfile(String profile) {
		this.profile = profile;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
}
