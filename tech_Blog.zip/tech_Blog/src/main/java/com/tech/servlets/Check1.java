package com.tech.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Check1
 */
@WebServlet("/Check1")
public class Check1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String quest1="f",quest2="f",quest3="f",quest4="f";
		if(request.getParameter("name1")!=null)
		{
			 quest1=request.getParameter("name1");
		}
		if(request.getParameter("name2")!=null)
		{
			quest2=request.getParameter("name2");
		}
		if(request.getParameter("name3")!=null)
		{
			 quest3=request.getParameter("name3");
		}
		if(request.getParameter("name4")!=null)
		{
		 quest4=request.getParameter("name4");
		}
		
		
		
		int count=0;
		
		
		
		if(quest1.equals("true"))
		{
			count++;
		}
		if(quest2.equals("true"))
		{
			count++;
		}
		if(quest3.equals("true"))
		{
			count++;
		}
		if(quest4.equals("true"))
		{
			count++;
		}
		out.print("<div style='position:relative;top:300px;'>");
		out.print("<h1 style='text-align:center; font-size:50px'>Thank you..</h1>");
		
		out.print("<h2 style='text-align:center;'>Result:&nbsp;&nbsp;"+count+" / 4");
		
		out.print("</h2>");
		
		out.print("</br>");
		
		out.print("<a href='Quiz/quiz_main.jsp' style='width:100px; height:40px; padding:7px; text-decoration:none;color:white;background-color:rgb(16, 180, 16);position:relative;left:650px;'>Go To Home</a>");
		out.print("</div>");
	}

}
