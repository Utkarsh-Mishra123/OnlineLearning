package com.tech.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddSubjects
 */
@WebServlet("/AddSubjects")
public class AddSubjects extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		 // JDBC driver and database URL
        String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost:3306/utkarsh";

        // Database credentials
        String USER = "root";
        String PASS = "Utkarsh$2002";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Extract parameters from the request
            String id = request.getParameter("Subjectid");
            String subjectName = request.getParameter("SubjectTitle");

            // Create SQL query
            String sql = "INSERT INTO subjects (subject_id,subject_name) VALUES (?,?)";

            // Create prepared statement
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, id);
            stmt.setString(2, subjectName);
            

            // Execute the statement
            int rowsAffected = stmt.executeUpdate();

            // Check if the subject was added successfully
            if (rowsAffected > 0) {
            	response.sendRedirect("admin.jsp");
            } else {
                out.println("<h2>Failed to add subject</h2>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                // Close resources
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
	}

}